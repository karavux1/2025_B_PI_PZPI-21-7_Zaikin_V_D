package com.example.demo.controllers;

import com.example.demo.ROLES;
import com.example.demo.model.Student;
import com.example.demo.services.SecurityService;
import com.example.demo.services.StudentService;
import com.example.demo.services.UIConfigurationService;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Controller
public class StudentsController {

    private final StudentService studentService;
    private final SecurityService securityService;
    private final UIConfigurationService UI;

    public StudentsController(StudentService studentService, SecurityService securityService, UIConfigurationService UI) {
        this.studentService = studentService;
        this.securityService = securityService;
        this.UI = UI;
    }

    @GetMapping({"/", "/rating"})
    public String filterRating(@RequestParam(required = false) String course,
                               @RequestParam(required = false) String department,
                               @RequestParam(required = false) String group,
                               Model model) {

        System.out.println(securityService.getRole());


        List<String> departments = studentService.getAllDepartments();
        List<String> groups = studentService.getAllGroups(); // Assuming a similar method exists for groups if needed
        List<Integer> courses = studentService.getAllCourses();// Assume this method returns a list of course numbers or identifiers

        if (department == null && !departments.isEmpty()) {
            department = departments.get(0);
        }
        if (course == null && !courses.isEmpty()) {
            course = String.valueOf(courses.get(0));
        }

        List<Student> students = studentService.filterStudents(course, department, group);
        if (securityService.getRole().equals(ROLES.GUEST) || securityService.getRole().equals(ROLES.USER)) {
            students = students.stream().filter(Student::isNotPrivate).collect(Collectors.toList());
        }
        students = students.stream().sorted(Comparator.comparingInt(Student::getRatingPlace)).collect(Collectors.toList());
        model.addAttribute("students", students);
        model.addAttribute("departments", departments);
        model.addAttribute("groups", groups);
        model.addAttribute("courses", courses);
        UI.configureFragments(model, "rating");
        return "layout";
    }
}
