package com.example.demo.model;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.List;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String email;
    private String photoUrl;
    private String department;
    private String groupName;
    private int course;
    private int score;
    private int ratingPlace;
    private boolean isPrivate;

    public Student(String name, String email, String photoUrl, String department, String groupName, int course, int score, int ratingPlace, boolean isPrivate) {
        this.name = name;
        this.email = email;
        this.photoUrl = photoUrl;
        this.department = department;
        this.groupName = groupName;
        this.course = course;
        this.score = score;
        this.ratingPlace = ratingPlace;
        this.isPrivate = isPrivate;
    }

    public boolean isNotPrivate() {
        return !isPrivate;
    }
}
