package com.example.demo;

public class DATATYPE {

    public static final String AWARD = "AWARD";
    public static final String[] AWARD_FIELDS = new String[]{
            "name", "teacherEmail", "studentEmail", "points", "weight", "semester", "approved"};
    public static final String STUDENT = "STUDENT";
    public static final String[] STUDENT_FIELDS = new String[]{
            "name", "email", "photoUrl", "department", "groupName", "course", "score", "ratingPlace", "isPrivate"};
    public static final String USER = "USER";
    public static final String[] USER_FIELDS = new String[]{"firstName", "lastName", "email", "password", "roles"};

}
