package com.example.demo.services;

import com.example.demo.DTO.RegistrationDTO;
import com.example.demo.ROLES;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Service;

import java.util.stream.Collectors;

@Service
public class SecurityService {
    final StudentService studentService;
    final UserService userService;

    public SecurityService(StudentService studentService, UserService userService) {
        this.studentService = studentService;
        this.userService = userService;
    }

    public boolean isOAuth2User() {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return principal instanceof OAuth2User;
    }

    public UserDetails getCurrentUserDetails() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.isAuthenticated() &&
                !(authentication instanceof AnonymousAuthenticationToken)) {
            Object principal = authentication.getPrincipal();
            if (principal instanceof UserDetails) {
                return (UserDetails) principal;
            } else if (principal instanceof OAuth2User) {
                return convertOAuth2UserToUserDetails((OAuth2User) principal);
            }
        }
        return null;
    }

    public RegistrationDTO buildRegistrationDtoFromOAuth2User(OAuth2User oAuth2User) {
        String firstName = oAuth2User.getAttribute("given_name");
        String lastName = oAuth2User.getAttribute("family_name");
        String email = oAuth2User.getAttribute("email");

        return new RegistrationDTO(firstName, lastName, email, null);
    }

    public UserDetails convertOAuth2UserToUserDetails(OAuth2User oAuth2User) {
        String email = oAuth2User.getAttribute("email");
        String name = oAuth2User.getAttribute("name");

        return new org.springframework.security.core.userdetails.User(
                email != null ? email : name, "", oAuth2User.getAuthorities());
    }

    public String getRole() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication instanceof AnonymousAuthenticationToken) {
            return ROLES.GUEST;
        }
        String email = getCurrentUserDetails().getUsername();
        if (userService.loadUserByUsername(email) != null) {
            return userService.loadUserByUsername(email).getRoles();
            // return authentication.getAuthorities().stream().map(GrantedAuthority::getAuthority).collect(Collectors.joining(", "));
        }
        if (authentication instanceof OAuth2AuthenticationToken) {
            RegistrationDTO dto = buildRegistrationDtoFromOAuth2User(((OAuth2AuthenticationToken) authentication)
                    .getPrincipal());
            String role = ROLES.USER;
            if (studentService.getStudentByEmail(dto.getEmail()) != null) {
                role = ROLES.STUDENT;
            }
            dto.setPassword("filthy password");
            userService.registerUser(dto, role);
            return role;
        }
        return ROLES.GUEST;
    }
}
