package com.example.demo;

public class ROLES {
    public static final String GUEST = "ROLE_GUEST";
    public static final String USER = "ROLE_USER";
    public static final String TEACHER = "ROLE_TEACHER";
    public static final String STUDENT = "ROLE_STUDENT";
    public static final String ADMIN = "ROLE_ADMIN";
}
