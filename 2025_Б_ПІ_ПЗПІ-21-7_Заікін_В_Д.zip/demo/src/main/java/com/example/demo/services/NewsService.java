package com.example.demo.services;

import com.example.demo.model.News;
import com.example.demo.repository.NewsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

@Service
public class NewsService {
    private final NewsRepository newsRepository;

    @Autowired
    public NewsService(NewsRepository newsRepository) {
        this.newsRepository = newsRepository;

        // Check and add initial news items if they do not already exist
        if (newsRepository.count() == 0) {
            addInitialNews();
        }
    }

    private void addInitialNews() {
        News news1 = new News();
        news1.setTitle("Welcome to Our New System");
        news1.setContent("We are excited to announce the launch of our new system!");
        news1.setTimestamp(LocalDateTime.now().minusDays(2)); // Set the timestamp to 2 days ago
        news1.setAuthorEmail("admin@example.com");

        News news2 = new News();
        news2.setTitle("System Maintenance");
        news2.setContent("Our system will be down for maintenance on Sunday from 2 AM to 4 AM.");
        news2.setTimestamp(LocalDateTime.now().minusDays(1)); // Set the timestamp to 1 day ago
        news2.setAuthorEmail("admin@example.com");

        News news3 = new News();
        news3.setTitle("New Features Released");
        news3.setContent("We have released several new features. Check them out in the 'Features' section.");
        news3.setTimestamp(LocalDateTime.now()); // Set the timestamp to now
        news3.setAuthorEmail("admin@example.com");

        newsRepository.save(news1);
        newsRepository.save(news2);
        newsRepository.save(news3);
    }

    public List<News> getAllNews() {
        List<News> newsList = newsRepository.findAll();
        newsList.sort(Comparator.comparing(News::getTimestamp).reversed());
        return newsList;
    }

    public void addNews(News news) {
        news.setTimestamp(LocalDateTime.now());
        newsRepository.save(news);
    }

    public News getNewsById(Long id) {
        Optional<News> optionalNews = newsRepository.findById(id);
        return optionalNews.orElseThrow(() -> new RuntimeException("News not found"));
    }

    public void updateNews(News news) {
        News existingNews = getNewsById(news.getId());
        existingNews.setTitle(news.getTitle());
        existingNews.setContent(news.getContent());
        newsRepository.save(existingNews);
    }

    public void deleteNews(Long id) {
        newsRepository.deleteById(id);
    }
}
