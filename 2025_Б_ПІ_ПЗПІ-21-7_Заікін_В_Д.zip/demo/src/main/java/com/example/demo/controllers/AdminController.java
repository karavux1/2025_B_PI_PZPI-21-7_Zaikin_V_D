package com.example.demo.controllers;

import com.example.demo.DTO.RegistrationDTO;
import com.example.demo.model.Student;
import com.example.demo.services.StudentService;
import com.example.demo.services.UIConfigurationService;
import com.example.demo.services.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class AdminController {
    final UserService userService;
    final UIConfigurationService UI;
    final StudentService studentService;

    public AdminController(UserService userService, UIConfigurationService ui, StudentService studentService) {
        this.userService = userService;
        UI = ui;
        this.studentService = studentService;
    }
    @GetMapping("/admin/add_user")
    public String showAddUserForm(Model model) {
        UI.configureFragments(model, "admin/add_user");
        return "layout";
    }
    @GetMapping("/admin/add_student")
    public String showAddStudentForm(Model model) {
        UI.configureFragments(model, "admin/add_student");
        return "layout";
    }
    @GetMapping("/admin/delete")
    public String showDeleteForm(Model model) {
        UI.configureFragments(model, "admin/delete");
        return "layout";
    }


    @PostMapping("/admin/delete")
    public String deleteEntity(@RequestParam String type, @RequestParam String email, RedirectAttributes redirectAttributes) {
        if ("USER".equals(type)) {
            userService.deleteUserByEmail(email);
            redirectAttributes.addFlashAttribute("successMessage", "User successfully deleted!");
        } else if ("STUDENT".equals(type)) {
            studentService.deleteStudentByEmail(email);
            redirectAttributes.addFlashAttribute("successMessage", "Student successfully deleted!");
        } else {
            redirectAttributes.addFlashAttribute("errorMessage", "Invalid type selected!");
        }
        return "redirect:/extra";
    }

    @PostMapping("/admin/add_student")
    public String addStudent(@ModelAttribute Student student, RedirectAttributes redirectAttributes) {
        studentService.addStudentIfNotExist(student);




        redirectAttributes.addFlashAttribute("successMessage", "Student successfully added!");
        return "redirect:/extra";
    }

    @PostMapping("/admin/add_user")
    public String addUser(@ModelAttribute RegistrationDTO registrationDTO, @RequestParam String role, RedirectAttributes redirectAttributes) {

        userService.registerUser(registrationDTO, role);




        redirectAttributes.addFlashAttribute("successMessage", "User successfully added!");
        return "redirect:/extra";
    }
}
