package com.example.demo.services;

import com.example.demo.model.Award;
import com.example.demo.model.Diploma;
import com.example.demo.model.Student;
import com.example.demo.repository.AwardRepository;
import com.example.demo.repository.DiplomaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class AwardService {
    private final AwardRepository awardRepository;
    private final DiplomaRepository diplomaRepository;

    @Autowired
    public AwardService(AwardRepository awardRepository, DiplomaRepository diplomaRepository) {
        this.awardRepository = awardRepository;
        this.diplomaRepository = diplomaRepository;
        awardRepository.save(new Award(1L, "Start award", "teacher@email.com", "student@email.com", 100, 0.2, 2, true));
        awardRepository.save(new Award(2L, "Second award", "teacher@email.com", "student2@email.com", 150, 0.3, 2, false));
        awardRepository.save(new Award(3L, "Third award", "teacher@email.com", "student@email.com", 200, 0.4, 2, true));
        awardRepository.save(new Award(4L, "Fourth award", "teacher@email.com", "student1@email.com", 120, 0.25, 2, false));
        awardRepository.save(new Award(5L, "Fifth award", "teacher@email.com", "student2@email.com", 180, 0.35, 2, true));
        awardRepository.save(new Award(6L, "Sixth award", "teacher@email.com", "student3@email.com", 220, 0.45, 2, false));
        awardRepository.save(new Award(7L, "Seventh award", "teacher@email.com", "student1@email.com", 130, 0.22, 2, true));
        awardRepository.save(new Award(8L, "Eighth award", "teacher@email.com", "student2@email.com", 160, 0.32, 2, false));
        awardRepository.save(new Award(9L, "Ninth award", "teacher@email.com", "student@email.com", 210, 0.42, 2, true));
        awardRepository.save(new Award(10L, "Tenth award", "teacher@email.com", "student1@email.com", 140, 0.27, 2, false));
        awardRepository.save(new Award(11L, "Eleventh award", "teacher@email.com", "student2@email.com", 170, 0.37, 2, true));
        awardRepository.save(new Award(12L, "Twelfth award", "teacher@email.com", "student3@email.com", 230, 0.47, 2, false));
        awardRepository.save(new Award(13L, "Thirteenth award", "teacher@email.com", "student4@email.com", 150, 0.29, 2, true));
        awardRepository.save(new Award(14L, "Fourteenth award", "teacher@email.com", "student2@email.com", 190, 0.39, 2, true));
        awardRepository.save(new Award(15L, "Fifteenth award", "teacher@email.com", "student2@email.com", 240, 0.49, 2, true));
        awardRepository.save(new Award(16L, "Sixteenth award", "teacher@email.com", "student2@email.com", 160, 0.31, 2, true));
        awardRepository.save(new Award(17L, "Seventeenth award", "teacher@email.com", "student2@email.com", 200, 0.41, 1, true));
        awardRepository.save(new Award(18L, "Eighteenth award", "teacher@email.com", "student2@email.com", 250, 0.51, 1, true));
        awardRepository.save(new Award(19L, "Nineteenth award", "teacher@email.com", "student2@email.com", 170, 0.33, 1, true));
        awardRepository.save(new Award(20L, "Twentieth award", "teacher@email.com", "student2@email.com", 210, 0.43, 1, true));

    }

    public void addAward(Award award) {
        awardRepository.save(award);
    }

    public List<Award> getUnapprovedAwards() {
        return awardRepository.findAll().stream().filter(a -> !a.isApproved()).collect(Collectors.toList());
    }

    public List<Award> getApprovedAwardsByStudentEmail(String studentEmail) {
        return awardRepository.findByStudentEmail(studentEmail).stream().filter(Award::isApproved).collect(Collectors.toList());
    }

    public void updateAward(Award award) {
        awardRepository.save(award);
    }

    public void approveAward(Long awardId) {
        Award award = awardRepository.findById(awardId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid award ID: " + awardId));
        award.setApproved(true);
        if (award.getDiplomaFileName() != null) {
            Diploma diploma = diplomaRepository.findByFileName(award.getDiplomaFileName()).get(0);
            if (diploma != null) {
                diploma.setApproved(true);
                diplomaRepository.save(diploma);
            }
        }
        awardRepository.save(award);
    }

    public void discardAward(Long awardId) {
        awardRepository.deleteById(awardId);
    }

    public Award getAwardById(long id) {
        return awardRepository.findById(id).orElse(null);
    }

    public static int getSemesterOfCourse(int course) {
        return course * 2 - (LocalDateTime.now().getDayOfYear() < 180 ? 0 : 1);
    }

    public List<Award> getStudentAwardsLastSemester(Student student) {
        int studentSemester = AwardService.getSemesterOfCourse(student.getCourse());
        return getApprovedAwardsByStudentEmail(student.getEmail()).stream()
                .filter(a -> a.getSemester() == studentSemester).collect(Collectors.toList());
    }

    public List<Award> getStudentAwardsLastYear(Student student) {
        int studentSemester = AwardService.getSemesterOfCourse(student.getCourse());
        return getApprovedAwardsByStudentEmail(student.getEmail()).stream()
                .filter(a ->
                        a.getSemester() == studentSemester || a.getSemester() == studentSemester - 1
                ).collect(Collectors.toList());
    }

    public void sendDiplomaAwardToReview(Diploma diploma, Student student) {
        Award award = new Award();
        award.setApproved(false);
        award.setStudentEmail(diploma.getStudentEmail());
        award.setWeight(0.1);
        award.setPoints(100);
        award.setSemester(AwardService.getSemesterOfCourse(student.getCourse()));
        award.setName("Award for diploma + " + diploma.getFileName());
        award.setTeacherEmail("Diploma");
        award.setDiplomaFileName(diploma.getFileName());
        awardRepository.save(award);
    }


}
