package com.example.demo.repository;

import com.example.demo.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface StudentRepository extends JpaRepository<Student, Long> {
    Student findStudentByEmail(String studentEmail);

    @Query("SELECT s FROM Student s WHERE " +
            "(:course IS NULL OR s.course = :course) AND " +
            "(:department IS NULL OR s.department = :department) AND " +
            "(:groupName IS NULL OR s.groupName = :groupName)")
    List<Student> findByCriteria(@Param("course") Integer course,
                                 @Param("department") String department,
                                 @Param("groupName") String groupName);

    @Query("SELECT s FROM Student s WHERE " +
            "(:course IS NULL OR s.course = :course) AND " +
            "(:department IS NULL OR s.department = :department)")
    List<Student> findByCriteriaAllGroups(@Param("course") Integer course,
                                          @Param("department") String department);

    @Query("SELECT DISTINCT s.department FROM Student s")
    List<String> findAllDepartments();

    @Query("SELECT DISTINCT s.groupName FROM Student s")
    List<String> findAllGroups();

    @Query("SELECT DISTINCT s.course FROM Student s")
    List<Integer> findAllCourses();

    void deleteByEmail(String email);

}
