package com.example.demo.services;

import com.example.demo.ROLES;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

@Service
public class UIConfigurationService {
    @Autowired
    private SecurityService securityService;

    public void configureNavigation(Model model) {
        String role = securityService.getRole();
        switch (role) {
            case ROLES.ADMIN -> model.addAttribute("navFragment", "nav/nav_admin");
            case ROLES.TEACHER -> model.addAttribute("navFragment", "nav/nav_teacher");
            case ROLES.STUDENT -> model.addAttribute("navFragment", "nav/nav_student");
            case ROLES.USER -> model.addAttribute("navFragment", "nav/nav_user");
            default -> model.addAttribute("navFragment", "nav/nav_guest");
        }
    }

    public void configureHead(Model model) {
        String role = securityService.getRole();
        if (role.equals(ROLES.GUEST)) {
            model.addAttribute("headFragment", "head/head_guest");
        } else {
            model.addAttribute("headFragment", "head/head_authorized");
        }
    }

    public void configureFragments(Model model, String content) {
        configureHead(model);
        configureNavigation(model);
        model.addAttribute("contentFragment", content);
    }
}
