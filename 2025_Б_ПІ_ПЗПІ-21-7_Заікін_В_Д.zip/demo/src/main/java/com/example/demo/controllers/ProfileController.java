package com.example.demo.controllers;

import com.example.demo.ROLES;
import com.example.demo.model.Diploma;
import com.example.demo.model.Student;
import com.example.demo.model.User;
import com.example.demo.services.SecurityService;
import com.example.demo.services.StudentService;
import com.example.demo.services.UIConfigurationService;
import com.example.demo.services.UserService;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

@Controller
public class ProfileController {

    private final StudentService studentService;
    private final UserService userService;
    private final SecurityService securityService;
    private final UIConfigurationService UI;

    public ProfileController(StudentService studentService, UserService userService, SecurityService securityService, UIConfigurationService UI) {
        this.studentService = studentService;
        this.userService = userService;
        this.securityService = securityService;
        this.UI = UI;
    }

    @GetMapping("/profile")
    public String showProfile(@RequestParam(value = "email", required = false) String email, Model model) {
        String role = securityService.getRole();
        if (email != null) {
            studentProfile(email, model);
        } else if (ROLES.STUDENT.equals(role)) {
            studentProfile(model);
        } else {
            userProfile(model);
        }
        return "layout";
    }

    private void userProfile(Model model) {
        String email = securityService.getCurrentUserDetails().getUsername();
        System.out.println(email);
        User user = userService.loadUserByUsername(email);
        model.addAttribute("user", user);
        UI.configureFragments(model, "profile/profile");
    }

    private void studentProfile(Model model) {
        String email = securityService.getCurrentUserDetails().getUsername();
        studentProfile(email, model);
    }

    private void studentProfile(String email, Model model) {
        Student student = studentService.getStudentByEmail(email);
        model.addAttribute("student", student);
        List<Diploma> diplomas = studentService.getAllDiplomasByEmail(email);
        diplomas = diplomas.stream().filter(Diploma::isApproved).collect(Collectors.toList());
        model.addAttribute("diplomas", diplomas);
        UserDetails user = securityService.getCurrentUserDetails();
        model.addAttribute("isCurrentUser", email.equals(user == null ? "" : user.getUsername()));
        UI.configureFragments(model, "profile/student_profile");
    }

    @GetMapping("/uploads/{filename:.+}")
    @ResponseBody
    public ResponseEntity<Resource> downloadDiploma(@PathVariable String filename) {
        try {
            Resource resource = studentService.loadAsResource(filename);
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"")
                    .body(resource);
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(null);
        }
    }

    @PostMapping("/uploadProfilePicture")
    public ResponseEntity<?> uploadProfilePicture(@RequestParam("file") MultipartFile file) {
        if (file.isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of("success", false));
        }
        try {
            String filename = UUID.randomUUID().toString() + "-" + file.getOriginalFilename();
            Path path = Paths.get("pictures/" + filename);
            Files.createDirectories(path.getParent());
            file.transferTo(path);
            String url = "/pictures/" + filename;
            studentService.updateStudentProfileImage(securityService.getCurrentUserDetails().getUsername(), url);
            return ResponseEntity.ok(Map.of("success", true, "url", url));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("success", false));
        }
    }

    @PostMapping("/updateProfilePrivacy")
    @ResponseBody
    public ResponseEntity<?> updateProfilePrivacy(@RequestBody Map<String, Boolean> payload) {
        boolean isPrivate = payload.get("isPrivate");
        try {
            String email = securityService.getCurrentUserDetails().getUsername();
            studentService.updateStudentPrivacy(email, isPrivate);
            return ResponseEntity.ok(Map.of("success", true));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("success", false));
        }
    }

}
