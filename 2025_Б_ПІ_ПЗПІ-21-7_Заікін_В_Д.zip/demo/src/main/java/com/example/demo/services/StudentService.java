package com.example.demo.services;

import com.example.demo.model.Award;
import com.example.demo.model.Diploma;
import com.example.demo.model.Notification;
import com.example.demo.model.Student;
import com.example.demo.repository.DiplomaRepository;
import com.example.demo.repository.StudentRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class StudentService {
    private final StudentRepository students;
    private final NotificationService notificationService;
    private final AwardService awardService;
    private final DiplomaRepository diplomaRepository;

    @Autowired
    public StudentService(StudentRepository students, NotificationService notificationService, AwardService awardService, DiplomaRepository diplomaRepository) {
        this.students = students;
        String photo = "https://as2.ftcdn.net/v2/jpg/02/60/19/05/1000_F_260190542_GIZO0eVLXwIoT0QoJ5ZlZQkwvwCmZNpf.jpg";
        addStudentIfNotExist(new Student(1L, "User0", "student@email.com", photo, "CS", "CS_010", 1, 0, 0, false));
        addStudentIfNotExist(new Student(2L, "User1", "student1@email.com", photo, "CS", "CS_010", 1, 0, 0, false));
        addStudentIfNotExist(new Student(3L, "User2", "student2@email.com", photo, "CS", "CS_010", 1, 0, 0, false));
        addStudentIfNotExist(new Student(4L, "User3", "student3@email.com", photo, "CS", "CS_010", 1, 0, 0, false));
        addStudentIfNotExist(new Student(5L, "User4", "student4@email.com", photo, "CS", "CS_020", 1, 0, 0, false));
        addStudentIfNotExist(new Student(6L, "User5", "student5@email.com", photo, "CS", "CS_020", 1, 0, 0, false));
        addStudentIfNotExist(new Student(7L, "User6", "student6@email.com", photo, "CS", "CS_020", 1, 0, 0, false));
        addStudentIfNotExist(new Student(8L, "User7", "student7@email.com", photo, "IT", "IT_010", 1, 0, 0, false));
        addStudentIfNotExist(new Student(9L, "User8", "student8@email.com", photo, "IT", "IT_010", 1, 0, 0, false));
        addStudentIfNotExist(new Student(10L, "User9", "student9@email.com", photo, "IT", "IT_010", 1, 0, 0, false));
        addStudentIfNotExist(new Student(11L, "User10", "student10@email.com", photo, "IT", "IT_020", 1, 0, 0, true));
        addStudentIfNotExist(new Student(12L, "User11", "student11@email.com", photo, "IT", "IT_020", 1, 0, 0, true));
        addStudentIfNotExist(new Student(13L, "User12", "student12@email.com", photo, "IT", "IT_020", 1, 0, 0, true));
        addStudentIfNotExist(new Student(14L, "User13", "student13@email.com", photo, "CS", "CS_010", 1, 0, 0, true));
        addStudentIfNotExist(new Student(15L, "User14", "student14@email.com", photo, "CS", "CS_010", 1, 0, 0, true));
        addStudentIfNotExist(new Student(16L, "User15", "student15@email.com", photo, "CS", "CS_010", 1, 0, 0, true));
        addStudentIfNotExist(new Student(17L, "User16", "student16@email.com", photo, "CS", "CS_020", 2, 0, 0, true));
        addStudentIfNotExist(new Student(18L, "User17", "student17@email.com", photo, "CS", "CS_020", 2, 0, 0, true));
        addStudentIfNotExist(new Student(19L, "User18", "student18@email.com", photo, "CS", "CS_020", 2, 0, 0, true));
        addStudentIfNotExist(new Student(20L, "User19", "student19@email.com", photo, "IT", "IT_010", 2, 0, 0, true));
        addStudentIfNotExist(new Student(21L, "User20", "student20@email.com", photo, "IT", "IT_010", 2, 0, 0, true));

        this.notificationService = notificationService;
        this.awardService = awardService;

        this.diplomaRepository = diplomaRepository;
    }

    @Transactional
    public void addStudentIfNotExist(Student student) {
        if (getStudentByEmail(student.getEmail()) == null) {
            student.setId(null);
            students.save(student);
        }
    }

    public List<Student> getAllStudents() {
        return students.findAll();
    }

    public Student getStudentByEmail(String email) {
        return students.findStudentByEmail(email);
    }

    public void recalculatePointsByAwards(String studentEmail, List<Award> awards) {
        Student student = getStudentByEmail(studentEmail);
        student.setScore((int) getScore(awards, student));
        students.save(student);
    }

    @Transactional
    public void recalculateAllStudentsAwards() {
        List<Student> allStudents = students.findAll();
        for (Student student : allStudents) {
            List<Award> approvedAwards = awardService.getApprovedAwardsByStudentEmail(student.getEmail());
            double newScore = getScore(approvedAwards, student);
            student.setScore((int) newScore);
            students.save(student);
        }
    }

    private double getScore(List<Award> awards, Student student) {
        double score = 0;
        for (Award award : awards) {
            if (award.getSemester() == AwardService.getSemesterOfCourse(student.getCourse())) {//awards set to 0 every semester
                score += award.getPoints() * award.getWeight();
            }
        }
        return score;
    }

    @Scheduled(fixedRate = 60000) // every 1 minute
    //@Scheduled(cron = "0 0 12 * * ?") // every 12:00
    @Transactional
    public void updateStudentRatingPlaces() {
        System.out.println("Rating recalculation started");
        recalculateAllStudentsAwards();
        List<Student> allStudents = students.findAll();

        Map<String, Map<Integer, List<Student>>> groupedByDepartmentAndCourse =
                allStudents.stream().collect(Collectors.groupingBy(Student::getDepartment,
                        Collectors.groupingBy(Student::getCourse)));

        for (Map.Entry<String, Map<Integer, List<Student>>> deptEntry : groupedByDepartmentAndCourse.entrySet()) {
            for (Map.Entry<Integer, List<Student>> courseEntry : deptEntry.getValue().entrySet()) {
                List<Student> studentsInCourse = courseEntry.getValue();
                studentsInCourse.sort(Comparator.comparing(Student::getScore).reversed());
                for (int i = 0; i < studentsInCourse.size(); i++) {
                    Student student = studentsInCourse.get(i);
                    int previousRating = student.getRatingPlace();
                    int currentRating = i + 1;
                    student.setRatingPlace(currentRating);
                    students.save(student);
                    if (previousRating - currentRating != 0) {
                        notificationService.addNotification(new Notification(
                                "Your rating has been changed from " + previousRating +
                                        " to " + currentRating + " place"
                                , student));
                    }
                }
            }
        }
        System.out.println("Ratings recalculated");
    }

    public List<Student> filterStudents(String courseStr, String department, String group) {
        Integer course = null;
        if (courseStr != null && !courseStr.isEmpty()) {
            try {
                course = Integer.parseInt(courseStr);
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
        if (group == null || group.isEmpty()) {
            return students.findByCriteriaAllGroups(course, department);
        }
        return students.findByCriteria(course, department, group);
    }

    public List<String> getAllDepartments() {
        return students.findAllDepartments();
    }

    public List<String> getAllGroups() {
        return students.findAllGroups();
    }

    public List<Integer> getAllCourses() {
        return students.findAllCourses();
    }

    public List<Diploma> getAllDiplomasByEmail(String email) {
        return diplomaRepository.findByStudentEmail(email);
    }

    @Transactional
    public void updateStudentProfileImage(String email, String url) {
        Student student = getStudentByEmail(email);
        if (student == null) {
            return;
        }
        student.setPhotoUrl(url);
        students.save(student);
    }

    public void saveDiploma(MultipartFile file, String studentEmail) throws Exception {
        try {
            if (!file.isEmpty()) {
                Path directoryPath = Paths.get("uploads");
                Files.createDirectories(directoryPath);

                Path filePath = directoryPath.resolve(file.getOriginalFilename());
                Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

                Diploma diploma = new Diploma();
                diploma.setFileName(file.getOriginalFilename());
                diploma.setFileUrl(filePath.toString());
                diploma.setStudentEmail(studentEmail);
                diploma.setApproved(false);
                Student student = students.findStudentByEmail(studentEmail);
                awardService.sendDiplomaAwardToReview(diploma, student);
                diplomaRepository.save(diploma);
            }
        } catch (IOException e) {
            // Log the exception or handle it according to your error-handling strategy
            throw new RuntimeException("Failed to save the file", e);
        }
    }


    public Resource loadAsResource(String filename) {
        Diploma diploma = diplomaRepository.findByFileName(filename).get(0);
        try {
            Path file = Paths.get(diploma.getFileUrl()).normalize();
            Resource resource = new UrlResource(file.toUri());
            if (resource.exists() || resource.isReadable()) {
                return resource;
            } else {
                throw new RuntimeException("Could not read the file!");
            }
        } catch (MalformedURLException e) {
            throw new RuntimeException("Error: MalformedURLException", e);
        }
    }

    @Transactional
    public void deleteStudentByEmail(String email) {
        students.deleteByEmail(email);
    }

    @Transactional
    public void updateStudentPrivacy(String email, boolean isPrivate) {
        Student student = getStudentByEmail(email);
        student.setPrivate(isPrivate);
        students.save(student);
    }
}

