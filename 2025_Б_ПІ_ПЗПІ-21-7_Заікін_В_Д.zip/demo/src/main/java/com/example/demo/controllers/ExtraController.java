package com.example.demo.controllers;

import com.example.demo.DATATYPE;
import com.example.demo.ROLES;
import com.example.demo.services.*;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@Controller
public class ExtraController {
    private final UIConfigurationService UI;
    private final DataImportService dataImportService;
    private final ExcelTemplateService excelTemplateService;
    private final StudentService studentService;
    private final SecurityService securityService;

    public ExtraController(UIConfigurationService UI, DataImportService dataImportService, ExcelTemplateService excelTemplateService, StudentService studentService, SecurityService securityService) {
        this.UI = UI;
        this.dataImportService = dataImportService;
        this.excelTemplateService = excelTemplateService;
        this.studentService = studentService;
        this.securityService = securityService;
    }

    @GetMapping("/extra")
    public String showExtraFeatures(Model model) {
        String role = securityService.getRole();
        switch (role) {
            case ROLES.STUDENT -> {
                UI.configureFragments(model, "extra/extra_user");
            }
            case ROLES.ADMIN -> {
                UI.configureFragments(model, "extra/extra_admin");
                model.addAttribute("classes", List.of(DATATYPE.STUDENT, DATATYPE.AWARD, DATATYPE.USER));
            }
        }
        return "layout";
    }

    @PostMapping("/upload")
    public String uploadData(@RequestParam(value = "fileUpload", required = false) MultipartFile file, @RequestParam("type") String type) {
        try {
            if (!file.isEmpty()) {
                dataImportService.importData(file, type);
            }
            return "redirect:/extra?success=true";
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return "redirect:/extra?success=false";
        }

    }

    @GetMapping("/download-template")
    public void downloadTemplate(@RequestParam("type") String type, HttpServletResponse response) throws IOException {
        excelTemplateService.downloadExcelTemplate(type, response);
    }

    @PostMapping("/uploadDiploma")
    public String uploadDiploma(@RequestParam("diploma") MultipartFile diploma) {
        if (!diploma.isEmpty()) {
            try {
                studentService.saveDiploma(diploma, securityService.getCurrentUserDetails().getUsername());
                return "redirect:/extra?success=true";
            } catch (Exception e) {
                return "redirect:/extra?success=false";
            }
        }
        return "redirect:/extra?success=false";
    }
}
