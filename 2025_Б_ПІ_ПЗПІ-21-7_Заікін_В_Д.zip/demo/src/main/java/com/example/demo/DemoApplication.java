package com.example.demo;

import com.example.demo.DTO.RegistrationDTO;
import com.example.demo.services.UserService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class DemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class, args);
    }

    @Bean
    CommandLineRunner run(UserService userService) {
        return args -> {
            userService.registerUser(new RegistrationDTO("Teacher", "User", "teacher@email.com", "teacher"), ROLES.TEACHER);
            userService.registerUser(new RegistrationDTO("Admin", "User", "admin@email.com", "admin"), ROLES.ADMIN);
            userService.registerUser(new RegistrationDTO("Student", "User", "student@email.com", "student"), ROLES.STUDENT);
            userService.registerUser(new RegistrationDTO("Student", "User", "student2@email.com", "student"), ROLES.STUDENT);
            userService.registerUser(new RegistrationDTO("Student", "User", "student3@email.com", "student"), ROLES.STUDENT);
            userService.registerUser(new RegistrationDTO("Student", "User", "student4@email.com", "student"), ROLES.STUDENT);
            userService.registerUser(new RegistrationDTO("Student", "User", "student5@email.com", "student"), ROLES.STUDENT);
            userService.registerUser(new RegistrationDTO("Student", "User", "student6@email.com", "student"), ROLES.STUDENT);
            userService.registerUser(new RegistrationDTO("Student", "User", "student7@email.com", "student"), ROLES.STUDENT);
            userService.registerUser(new RegistrationDTO("Student", "User", "student8@email.com", "student"), ROLES.STUDENT);
            userService.registerUser(new RegistrationDTO("Student", "User", "student9@email.com", "student"), ROLES.STUDENT);
            userService.registerUser(new RegistrationDTO("Student", "User", "student10@email.com", "student"), ROLES.STUDENT);
        };
    }
}
