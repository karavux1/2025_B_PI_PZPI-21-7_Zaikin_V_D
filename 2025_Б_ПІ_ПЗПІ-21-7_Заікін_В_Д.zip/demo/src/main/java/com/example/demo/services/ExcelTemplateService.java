package com.example.demo.services;

import com.example.demo.DATATYPE;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@Service
public class ExcelTemplateService {
    private static final Map<String, String[]> FIELD_MAP = new HashMap<>();
    static {
        FIELD_MAP.put(DATATYPE.AWARD, DATATYPE.AWARD_FIELDS);
        FIELD_MAP.put(DATATYPE.STUDENT, DATATYPE.STUDENT_FIELDS);
        FIELD_MAP.put(DATATYPE.USER, DATATYPE.USER_FIELDS);
    }

    public void downloadExcelTemplate(String type, HttpServletResponse response) throws IOException {
        String[] headers = FIELD_MAP.getOrDefault(type, new String[0]);

        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("Template");

        XSSFRow headerRow = sheet.createRow(0);
        for (int i = 0; i < headers.length; i++) {
            XSSFCell cell = headerRow.createCell(i);
            cell.setCellValue(headers[i]);
        }

        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        response.setHeader("Content-Disposition", "attachment; filename=" + type.toLowerCase() + "_template.xlsx");
        workbook.write(response.getOutputStream());
        workbook.close();
    }
}
