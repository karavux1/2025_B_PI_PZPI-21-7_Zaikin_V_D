package com.example.demo.controllers;

import com.example.demo.model.Notification;
import com.example.demo.services.NotificationService;
import com.example.demo.services.SecurityService;
import com.example.demo.services.UIConfigurationService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.Comparator;
import java.util.List;

@Controller
public class NotificationsController {
    private final NotificationService notificationService;
    private final SecurityService securityService;
    private final UIConfigurationService UI;

    public NotificationsController(NotificationService notificationService, SecurityService securityService, UIConfigurationService UI) {
        this.notificationService = notificationService;
        this.securityService = securityService;
        this.UI = UI;
    }

    @GetMapping("/notifications")
    public String showNotifications(Model model) {
        String email = securityService.getCurrentUserDetails().getUsername();
        List<Notification> notifications = notificationService.getNotificationsByEmail(email);
        notifications.sort(Comparator.comparing(Notification::getTime).reversed());
        model.addAttribute("notifications", notifications);
        UI.configureFragments(model, "notifications");
        return "layout";
    }
}
