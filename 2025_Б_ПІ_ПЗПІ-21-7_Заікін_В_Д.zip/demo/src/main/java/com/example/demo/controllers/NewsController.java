package com.example.demo.controllers;

import com.example.demo.model.News;
import com.example.demo.services.NewsService;
import com.example.demo.services.SecurityService;
import com.example.demo.services.UIConfigurationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class NewsController {
    private final NewsService newsService;
    private final SecurityService securityService;
    private final UIConfigurationService uiConfigurationService;

    @Autowired
    public NewsController(NewsService newsService, SecurityService securityService, UIConfigurationService uiConfigurationService) {
        this.newsService = newsService;
        this.securityService = securityService;
        this.uiConfigurationService = uiConfigurationService;
    }

    @GetMapping("/news")
    public String showNewsBoard(Model model) {
        model.addAttribute("newsList", newsService.getAllNews());
        uiConfigurationService.configureFragments(model, "news/news_board");
        return "layout";
    }

    @GetMapping("/admin/add_news")
    public String showAddNewsForm(Model model) {
        model.addAttribute("news", new News());
        model.addAttribute("newsList", newsService.getAllNews());
        model.addAttribute("isEdit", false);
        uiConfigurationService.configureFragments(model, "news/add_news");
        return "layout";
    }

    @PostMapping("/admin/add_news")
    public String addNews(@ModelAttribute News news, RedirectAttributes redirectAttributes) {
        news.setAuthorEmail(securityService.getCurrentUserDetails().getUsername());
        newsService.addNews(news);
        redirectAttributes.addFlashAttribute("successMessage", "News successfully added!");
        return "redirect:/admin/add_news";
    }

    @GetMapping("/admin/edit_news/{id}")
    public String editNews(@PathVariable Long id, Model model) {
        News news = newsService.getNewsById(id);
        model.addAttribute("news", news);
        model.addAttribute("newsList", newsService.getAllNews());
        model.addAttribute("isEdit", true);
        uiConfigurationService.configureFragments(model, "news/add_news");
        return "layout";
    }

    @PostMapping("/admin/update_news")
    public String updateNews(@ModelAttribute News news, RedirectAttributes redirectAttributes) {
        newsService.updateNews(news);
        redirectAttributes.addFlashAttribute("successMessage", "News successfully updated!");
        return "redirect:/admin/add_news";
    }

    @PostMapping("/admin/delete_news")
    public String deleteNews(@RequestParam Long id, RedirectAttributes redirectAttributes) {
        newsService.deleteNews(id);
        redirectAttributes.addFlashAttribute("successMessage", "News successfully deleted!");
        return "redirect:/admin/add_news";
    }
}


