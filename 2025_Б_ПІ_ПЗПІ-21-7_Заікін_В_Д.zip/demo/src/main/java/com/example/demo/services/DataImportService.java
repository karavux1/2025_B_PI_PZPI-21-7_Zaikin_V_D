package com.example.demo.services;

import com.example.demo.DATATYPE;
import com.example.demo.model.Award;
import com.example.demo.model.Student;
import com.example.demo.model.User;
import com.example.demo.repository.AwardRepository;
import com.example.demo.repository.StudentRepository;
import com.example.demo.repository.UserRepository;
import com.opencsv.bean.ColumnPositionMappingStrategy;
import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.util.List;

@Service
public class DataImportService {
    private final AwardRepository awardRepository;
    private final StudentRepository studentRepository;

    private final UserService userService;

    public DataImportService(AwardRepository awardRepository, StudentRepository studentRepository, UserRepository userRepository, UserService userService) {
        this.awardRepository = awardRepository;
        this.studentRepository = studentRepository;
        this.userService = userService;
    }


    public void importData(MultipartFile file, String dataType) throws Exception {
        Class classType = null;
        JpaRepository repository = null;
        String[] fields = null;
        switch (dataType) {
            case DATATYPE.STUDENT -> {
                classType = Student.class;
                repository = studentRepository;
                fields = DATATYPE.STUDENT_FIELDS;
            }
            case DATATYPE.AWARD -> {
                classType = Award.class;
                repository = awardRepository;
                fields = DATATYPE.AWARD_FIELDS;
            }
            case DATATYPE.USER -> {
                classType = User.class;
                //repository = userRepository;//
                fields = DATATYPE.USER_FIELDS;
            }
            default -> {
                throw new IllegalArgumentException();
            }
        }
        if (!file.isEmpty()) {
            String contentType = file.getContentType();
            if ("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet".equals(contentType)) {
                importDataFromExcel(file, classType, repository);
            } else if ("text/csv".equals(contentType)) {
                importDataFromCSV(file, classType, fields, repository);
            }
        }
    }

    private <T> void importDataFromExcel(MultipartFile file, Class<T> type, JpaRepository<T, Long> repository) throws Exception {
        InputStream inputStream = file.getInputStream();
        Workbook workbook = new XSSFWorkbook(inputStream);
        Sheet sheet = workbook.getSheetAt(0); // assuming first sheet for simplicity

        Field[] fields = type.getDeclaredFields(); // Reflection to get all fields of the class
        DataFormatter dataFormatter = new DataFormatter();

        for (Row row : sheet) {
            if (row.getRowNum() == 0) continue; // Skip header

            T entity = type.getDeclaredConstructor().newInstance(); // Create new instance of type T

            for (int i = 1; i < fields.length; i++) {
                Field field = fields[i];
                field.setAccessible(true);
                Cell cell = row.getCell(i - 1);

                // Determine the type of the field and set value accordingly
                if (field.getType().equals(String.class)) {
                    field.set(entity, dataFormatter.formatCellValue(cell));
                } else if (field.getType().equals(long.class) || field.getType().equals(Long.class)) {
                    field.set(entity, Long.parseLong(cell.getStringCellValue()));
                } else if (field.getType().equals(int.class) || field.getType().equals(Integer.class)) {
                    field.set(entity, (int) cell.getNumericCellValue());
                } else if (field.getType().equals(double.class) || field.getType().equals(Double.class)) {
                    field.set(entity, Double.parseDouble(cell.getStringCellValue()));
                } else if (field.getType().equals(boolean.class) || field.getType().equals(Boolean.class)) {
                    field.set(entity, Boolean.parseBoolean(cell.getStringCellValue()));
                }
            }
            if (type.equals(User.class)) {
                User user = (User) entity;
                userService.registerUser(user);
            } else {
                repository.save(entity); // Save the populated entity
            }
        }
        workbook.close();
    }


    private <T> void importDataFromCSV(MultipartFile file, Class<T> type, String[] memberFieldsToBindTo, JpaRepository<T, Long> repository) {
        char delimiter;
        try (InputStream inputStream = file.getInputStream()) {
            delimiter = detectDelimiter(inputStream);
        } catch (IOException e) {
            throw new RuntimeException("Failed to detect delimiter or read CSV file", e);
        }

        try (InputStream inputStream = file.getInputStream()) {
            ColumnPositionMappingStrategy<T> strategy = new ColumnPositionMappingStrategy<>();
            strategy.setType(type);
            strategy.setColumnMapping(memberFieldsToBindTo);

            CsvToBean<T> csvToBean = new CsvToBeanBuilder<T>(new InputStreamReader(inputStream))
                    .withType(type)
                    .withSeparator(delimiter)
                    .withMappingStrategy(strategy)
                    .withSkipLines(1)
                    .withIgnoreLeadingWhiteSpace(true)
                    .build();

            List<T> entities = csvToBean.parse();
            repository.saveAll(entities);
        } catch (IOException e) {
            throw new RuntimeException("Failed to read CSV file after delimiter detection", e);
        }
    }
    private char detectDelimiter(InputStream inputStream) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
        String line = reader.readLine();

        if (line == null || line.isEmpty()) {
            return ',';
        }

        int commaCount = line.length() - line.replace(",", "").length();
        int semicolonCount = line.length() - line.replace(";", "").length();

        return (commaCount > semicolonCount) ? ',' : ';';
    }
}
