package com.example.demo.controllers;

import com.example.demo.DTO.RegistrationDTO;
import com.example.demo.ROLES;
import com.example.demo.services.EmailService;
import com.example.demo.services.StudentService;
import com.example.demo.services.UserService;
import jakarta.mail.MessagingException;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class LoginController {

    private final UserService userService;
    private final StudentService studentService;
    private final EmailService emailService;

    public LoginController(UserService userService, StudentService studentService, EmailService emailService) {
        this.userService = userService;
        this.studentService = studentService;
        this.emailService = emailService;
    }

    @GetMapping("/login")
    public String login() {
        return "login/login";
    }

    @GetMapping("/register")
    public String showRegistrationForm() {
        return "login/register";
    }

    @PostMapping("/register")
    public String registerUser(@ModelAttribute RegistrationDTO registrationDto) {
        if (userService.loadUserByUsername(registrationDto.getEmail()) != null) {
            return "redirect:/register?msg=user already registred";
        } else if (studentService.getStudentByEmail(registrationDto.getEmail()) != null) {
            userService.registerUser(registrationDto, ROLES.STUDENT);
        } else {
            userService.registerUser(registrationDto, ROLES.USER);
        }
        return "redirect:/login";
    }

    @GetMapping("/forgot_password")
    public String forgotPassword() {
        return "login/forgot_password";
    }

    @PostMapping("/forgot_password")
    public String processForgotPassword(HttpServletRequest request, @RequestParam("username") String email, RedirectAttributes redirectAttributes) {
        try {
            String token = userService.resetPassword(email); 
            String resetLink = request.getRequestURL().toString().replace(request.getServletPath(), "") + "/login?reset=true";
            emailService.sendEmailWithNewPassword(email, token, resetLink);
        } catch (UsernameNotFoundException | MessagingException ex) {
            System.out.println(ex.getMessage());
            return "redirect:/login?error=true";
        }
        return "redirect:/login?reset=true";
    }

}
