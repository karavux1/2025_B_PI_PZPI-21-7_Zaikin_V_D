package com.example.demo.services;

import com.example.demo.model.Notification;
import com.example.demo.repository.NotificationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NotificationService {
    NotificationRepository notifications;

    @Autowired
    public NotificationService(NotificationRepository notifications) {
        this.notifications = notifications;
    }

    public void addNotification(Notification notification) {
        notifications.save(notification);
    }

    public List<Notification> getNotificationsByEmail(String email) {
        return notifications.findStudentByStudentEmail(email);
    }
}
