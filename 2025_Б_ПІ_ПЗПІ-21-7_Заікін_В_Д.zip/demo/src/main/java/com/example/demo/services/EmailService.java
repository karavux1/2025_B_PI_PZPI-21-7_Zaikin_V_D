package com.example.demo.services;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    private final JavaMailSender mailSender;

    public EmailService(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    public void sendEmailWithNewPassword(String to, String newPassword, String link) throws MessagingException {
        String subject = "Password Reset Request";
        String content = "<p>Hello,</p>"
                + "<p>You have requested a password reset.</p>"
                + "<p>Here is your new password: <b>" + newPassword + "</b></p>"
                + "<p>Please change your password after logging in.</p>"
                + "<p>Click <a href='" + link + "'>here</a> to reset your password.</p>";

        MimeMessage message = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, true);

        helper.setFrom("noreply@gmail.com");
        helper.setTo(to);
        helper.setSubject(subject);
        helper.setText(content, true);

        mailSender.send(message);
    }
}
