package com.example.demo.controllers;

import com.example.demo.DTO.AwardDTO;
import com.example.demo.ROLES;
import com.example.demo.model.Award;
import com.example.demo.model.Student;
import com.example.demo.services.AwardService;
import com.example.demo.services.SecurityService;
import com.example.demo.services.StudentService;
import com.example.demo.services.UIConfigurationService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDateTime;
import java.util.List;

@Controller
public class AwardsController {
    private final AwardService awardService;
    private final StudentService studentService;
    private final SecurityService securityService;
    private final UIConfigurationService UI;

    public AwardsController(AwardService awardService, StudentService studentService, SecurityService securityService, UIConfigurationService UI) {
        this.awardService = awardService;
        this.studentService = studentService;
        this.securityService = securityService;
        this.UI = UI;
    }

    @GetMapping("/awards")
    public String showAwardsTable(@RequestParam(value = "timeFilter", required = false) String timeFilter, Model model) {
        String role = securityService.getRole();
        switch (role) {
            case ROLES.ADMIN -> adminAwards(model);
            case ROLES.TEACHER -> teacherAwards(model);
            case ROLES.STUDENT -> studentAwards(model, timeFilter);
        }
        return "layout";
    }

    private void studentAwards(Model model, String timeFilter) {
        String email = securityService.getCurrentUserDetails().getUsername();
        Student student = studentService.getStudentByEmail(email);
        if(timeFilter == null){
            timeFilter = "ALL";
        }
        switch (timeFilter) {
            case "lastSemester" -> model.addAttribute("awards", awardService.getStudentAwardsLastSemester(student));
            case "lastYear" -> model.addAttribute("awards", awardService.getStudentAwardsLastYear(student));
            default -> model.addAttribute("awards", awardService.getApprovedAwardsByStudentEmail(email)); // Default or in case of an invalid option
        }
        UI.configureFragments(model, "awards/awards_student");
    }

    private void teacherAwards(Model model) {
        List<Student> students = studentService.getAllStudents();
        model.addAttribute("students", students);
        model.addAttribute("awardDTO", new AwardDTO());
        UI.configureFragments(model, "awards/awards_teacher");
    }

    private void adminAwards(Model model) {
        List<Award> awards = awardService.getUnapprovedAwards();
        model.addAttribute("awards", awards);
        UI.configureFragments(model, "awards/awards_admin");
    }

    @PostMapping("/addAward")
    public String awardTeacher(@ModelAttribute AwardDTO awardDTO) {
        Award award = new Award();
        award.setName(awardDTO.getSubject());
        award.setPoints(awardDTO.getPoints());
        award.setWeight(awardDTO.getWeight());
        Student student = studentService.getStudentByEmail(awardDTO.getStudentEmail());
        award.setStudentEmail(student.getEmail());
        award.setTeacherEmail(securityService.getCurrentUserDetails().getUsername());
        award.setSemester(AwardService.getSemesterOfCourse(student.getCourse()));
        award.setApproved(false);
        awardService.addAward(award);
        return "redirect:/awards?awarded=true";
    }

    @PostMapping("/approveAward")
    public String approveAward(@RequestParam("awardId") Long awardId,
                               @RequestParam("points") int points,
                               @RequestParam("weight") double weight,
                               RedirectAttributes attributes) {
        Award award = awardService.getAwardById(awardId);
        award.setPoints(points);
        award.setWeight(weight);

        awardService.updateAward(award);
        awardService.approveAward(awardId);

        List<Award> awards = awardService.getApprovedAwardsByStudentEmail(award.getStudentEmail());
        studentService.recalculatePointsByAwards(award.getStudentEmail(), awards);

        attributes.addFlashAttribute("success", "Award approved successfully with updated points and weight!");
        return "redirect:/awards";
    }

    @PostMapping("/discardAward")
    public String discardAward(@RequestParam("awardId") Long awardId, RedirectAttributes attributes) {
        awardService.discardAward(awardId);
        attributes.addFlashAttribute("success", "Award discarded successfully!");
        return "redirect:/awards";
    }
}
