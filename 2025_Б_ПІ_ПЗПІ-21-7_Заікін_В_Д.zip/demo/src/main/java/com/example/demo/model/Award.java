package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Award {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String teacherEmail;
    private String studentEmail;
    private int points;
    private double weight;
    private int semester;
    private boolean approved;
    private String diplomaFileName;

    public Award(Long id, String name, String teacherEmail, String studentEmail, int points, double weight, int semester, boolean approved) {
        this.id = id;
        this.name = name;
        this.teacherEmail = teacherEmail;
        this.studentEmail = studentEmail;
        this.points = points;
        this.weight = weight;
        this.semester = semester;
        this.approved = approved;
    }
}

