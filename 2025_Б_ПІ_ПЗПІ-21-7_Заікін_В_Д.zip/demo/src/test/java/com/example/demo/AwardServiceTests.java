package com.example.demo;

import com.example.demo.model.Award;
import com.example.demo.model.Diploma;
import com.example.demo.model.Student;
import com.example.demo.repository.AwardRepository;
import com.example.demo.repository.DiplomaRepository;
import com.example.demo.services.AwardService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class AwardServiceTests {

    @Mock
    private AwardRepository awardRepository;

    @Mock
    private DiplomaRepository diplomaRepository;

    @InjectMocks
    private AwardService awardService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testAddAward() {
        Award award = new Award();
        awardService.addAward(award);
        verify(awardRepository, times(1)).save(award);
    }

    @Test
    void testGetUnapprovedAwards() {
        Award award1 = new Award();
        award1.setApproved(false);
        Award award2 = new Award();
        award2.setApproved(true);
        when(awardRepository.findAll()).thenReturn(Arrays.asList(award1, award2));
        List<Award> result = awardService.getUnapprovedAwards();
        assertEquals(1, result.size());
        assertFalse(result.get(0).isApproved());
    }

    @Test
    void testGetApprovedAwardsByStudentEmail() {
        Award award1 = new Award();
        award1.setApproved(true);
        award1.setStudentEmail("student@example.com");
        Award award2 = new Award();
        award2.setApproved(false);
        when(awardRepository.findByStudentEmail("student@example.com")).thenReturn(Arrays.asList(award1, award2));
        List<Award> result = awardService.getApprovedAwardsByStudentEmail("student@example.com");
        assertEquals(1, result.size());
        assertTrue(result.get(0).isApproved());
    }

    @Test
    void testApproveAward() {
        Award award = new Award();
        award.setId(1L);
        award.setDiplomaFileName("diploma.pdf");
        when(awardRepository.findById(1L)).thenReturn(Optional.of(award));
        Diploma diploma = new Diploma();
        diploma.setFileName("diploma.pdf");
        when(diplomaRepository.findByFileName("diploma.pdf")).thenReturn(Arrays.asList(diploma));

        awardService.approveAward(1L);

        assertTrue(award.isApproved());
        assertTrue(diploma.isApproved());
        verify(awardRepository, times(1)).save(award);
        verify(diplomaRepository, times(1)).save(diploma);
    }

    @Test
    void testDiscardAward() {
        awardService.discardAward(1L);
        verify(awardRepository, times(1)).deleteById(1L);
    }

    @Test
    void testGetAwardById() {
        Award award = new Award();
        award.setId(1L);
        when(awardRepository.findById(1L)).thenReturn(Optional.of(award));
        Award result = awardService.getAwardById(1L);
        assertEquals(award, result);
    }
}
